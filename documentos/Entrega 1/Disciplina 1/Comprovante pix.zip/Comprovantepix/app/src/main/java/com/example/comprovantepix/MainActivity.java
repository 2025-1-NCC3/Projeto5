package com.example.comprovantepix;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.ImageView;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final int PICK_IMAGE_REQUEST = 1;
    private ImageView imageViewPixComprovante;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageViewPixComprovante = findViewById(R.id.imageViewPixComprovante);
        Button btnAttachPix = findViewById(R.id.btnAttachPix);

        // Quando o botão de anexar for clicado, abre a galeria de imagens
        btnAttachPix.setOnClickListener(v -> {
            openFileChooser();
        });
    }

    // Função para abrir a galeria de imagens e selecionar o comprovante Pix
    private void openFileChooser() {
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("image/*"); // Só permite selecionar imagens
        startActivityForResult(intent, PICK_IMAGE_REQUEST);
    }

    // Função chamada quando o usuário escolhe a imagem
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && requestCode == PICK_IMAGE_REQUEST) {
            Uri imageUri = data.getData(); // Obtém a URI da imagem escolhida
            try {
                // Converte a URI em um Bitmap e exibe na ImageView
                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), imageUri);
                imageViewPixComprovante.setImageBitmap(bitmap); // Exibe a imagem no ImageView
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    // Função chamada ao clicar no botão Finalizar
    public void onFinalizeClick(android.view.View view) {
        // Aqui você pode processar o comprovante, por exemplo, enviá-lo para um servidor.
    }
}
