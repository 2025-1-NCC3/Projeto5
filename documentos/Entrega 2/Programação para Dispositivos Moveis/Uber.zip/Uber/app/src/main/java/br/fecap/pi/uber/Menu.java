package br.fecap.pi.uber;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

import br.fecap.pi.uber.R;
;

public class Menu extends AppCompatActivity {

    private Button btnLoc;
    private ImageView imgPerfil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        btnLoc = findViewById(R.id.btnLoc);
        imgPerfil = findViewById(R.id.imgPerfil);

        btnLoc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Abre a tela de busca de local
                Intent intent = new Intent(Menu.this, Procurar.class);
                startActivity(intent);
            }
        });

        imgPerfil.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Abre a tela de perfil
                Intent intent = new Intent(Menu.this, Perfil.class);
                startActivity(intent);
            }
        });
    }
}
