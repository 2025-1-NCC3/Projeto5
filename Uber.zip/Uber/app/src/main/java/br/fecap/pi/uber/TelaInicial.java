package br.fecap.pi.uber;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class TelaInicial extends AppCompatActivity {

    private EditText editTextEmail, editTextSenha;
    private Button buttonLogin, buttonRegister;
    private TextView textForgotPassword;

    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_inicial); // <- VERIFIQUE SE ESSE É O NOME CERTO DO XML

        db = new DatabaseHelper(this);

        editTextEmail = findViewById(R.id.none);
        editTextSenha = findViewById(R.id.senha);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonRegister = findViewById(R.id.buttonRegister);
        textForgotPassword = findViewById(R.id.textForgotPassword);

        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String emailOuNome = editTextEmail.getText().toString();
                String senha = editTextSenha.getText().toString();

                if (emailOuNome.isEmpty() || senha.isEmpty()) {
                    Toast.makeText(TelaInicial.this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
                } else {
                    boolean isValid = db.checkUser(emailOuNome, senha);
                    if (isValid) {
                        Toast.makeText(TelaInicial.this, "Login realizado com sucesso", Toast.LENGTH_SHORT).show();
                        // Redireciona para o menu principal
                        Intent intent = new Intent(TelaInicial.this, Menu.class);
                        startActivity(intent);
                        finish();
                    } else {
                        Toast.makeText(TelaInicial.this, "Credenciais inválidas", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(TelaInicial.this, MainActivity.class);
                startActivity(intent);
            }
        });

        textForgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(TelaInicial.this, "Recuperação de senha ainda não implementada", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
