package br.fecap.pi.uber;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;

public class DatabaseHelper extends SQLiteOpenHelper {

    public static final String DATABASE_NAME = "uber.db";
    public static final int DATABASE_VERSION = 1;

    public static final String TABLE_USERS = "users";
    public static final String COL_ID = "id";
    public static final String COL_NOME = "nome";
    public static final String COL_SOBRENOME = "sobrenome";
    public static final String COL_TELEFONE = "telefone";
    public static final String COL_EMAIL = "email";
    public static final String COL_SENHA = "senha";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createTable = "CREATE TABLE " + TABLE_USERS + " (" +
                COL_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                COL_NOME + " TEXT, " +
                COL_SOBRENOME + " TEXT, " +
                COL_TELEFONE + " TEXT, " +
                COL_EMAIL + " TEXT, " +
                COL_SENHA + " TEXT)";
        db.execSQL(createTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_USERS);
        onCreate(db);
    }

    public boolean registerUser(String nome, String sobrenome, String telefone, String email, String senha) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COL_NOME, nome);
        values.put(COL_SOBRENOME, sobrenome);
        values.put(COL_TELEFONE, telefone);
        values.put(COL_EMAIL, email);
        values.put(COL_SENHA, senha);

        long result = db.insert(TABLE_USERS, null, values);
        return result != -1;
    }

    public boolean checkUser(String email, String senha) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_USERS + " WHERE email = ? AND senha = ?", new String[]{email, senha});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }
}
