package com.example.uberlogin;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

import com.example.uber.R;

class TelaInicial extends AppCompatActivity {

    private EditText editTextEmail, editTextSenha;
    private Button buttonLogin, buttonRegister;
    private TextView textForgotPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        editTextEmail = findViewById(R.id.none);
        editTextSenha = findViewById(R.id.senha);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonRegister = findViewById(R.id.buttonRegister);
        textForgotPassword = findViewById(R.id.textForgotPassword);

        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String email = editTextEmail.getText().toString();
                String senha = editTextSenha.getText().toString();
                if (email.isEmpty() || senha.isEmpty()) {
                    Toast.makeText(com.example.uberlogin.TelaInicial.this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(com.example.uberlogin.TelaInicial.this, "Login realizado com sucesso", Toast.LENGTH_SHORT).show();
                }
            }
        });

        buttonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(com.example.uberlogin.TelaInicial.this, "Tela de cadastro ainda não implementada", Toast.LENGTH_SHORT).show();
            }
        });

        textForgotPassword.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(com.example.uberlogin.TelaInicial.this, "Recuperação de senha ainda não implementada", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
