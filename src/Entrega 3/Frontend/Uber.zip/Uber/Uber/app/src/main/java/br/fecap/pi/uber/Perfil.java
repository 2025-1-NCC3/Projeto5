package br.fecap.pi.uber;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class Perfil extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil);


        Button btnVerComprovantes = findViewById(R.id.btnVerComprovantes);
        btnVerComprovantes.setOnClickListener(v -> {
            Intent intent = new Intent(Perfil.this, historicosPix.class);
            startActivity(intent);
        });


        getWindow().setStatusBarColor(getResources().getColor(R.color.preto));
        getWindow().setNavigationBarColor(getResources().getColor(R.color.preto));


        ImageView imgMenu = findViewById(R.id.imgMenu);
        imgMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Perfil.this, Menu.class);
                startActivity(intent);
                finish();
            }
        });
    }
}
