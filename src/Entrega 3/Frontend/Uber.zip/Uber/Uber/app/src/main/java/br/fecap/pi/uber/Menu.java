package br.fecap.pi.uber;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class Menu extends AppCompatActivity {

    private Button btnLoc;
    private ImageView imgPerfil;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        btnLoc = findViewById(R.id.btnLoc);
        imgPerfil = findViewById(R.id.imgPerfil);

        btnLoc.setOnClickListener(view -> {

            Intent intent = new Intent(Menu.this, Procurar.class);
            startActivity(intent);
        });

        imgPerfil.setOnClickListener(view -> {

            Intent intent = new Intent(Menu.this, Perfil.class);
            startActivity(intent);
        });
    }
}
