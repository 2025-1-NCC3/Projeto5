package br.fecap.pi.uber;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class telaOpcoes extends AppCompatActivity {

    private Button btnVoltarViagem;
    private Button btnMudarForma;
    private Button btnCancelar;

    private double origemLat, origemLng, destinoLat, destinoLng;
    private String origemEndereco, destinoEndereco;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_opcoes);

        btnVoltarViagem = findViewById(R.id.btnVoltarViagem);
        btnMudarForma = findViewById(R.id.btnMudarForma);
        btnCancelar = findViewById(R.id.btnCancelar);


        Intent intent = getIntent();
        origemLat = intent.getDoubleExtra("origem_lat", 0);
        origemLng = intent.getDoubleExtra("origem_lng", 0);
        destinoLat = intent.getDoubleExtra("destino_lat", 0);
        destinoLng = intent.getDoubleExtra("destino_lng", 0);
        origemEndereco = intent.getStringExtra("origem_endereco");
        destinoEndereco = intent.getStringExtra("destino_endereco");


        btnMudarForma.setOnClickListener(view -> {
            Intent intentMudar = new Intent(telaOpcoes.this, mudarPagamento.class);
            startActivity(intentMudar);
        });


        btnVoltarViagem.setOnClickListener(view -> {
            Intent resultIntent = new Intent();

            resultIntent.putExtra("origem_lat", origemLat);
            resultIntent.putExtra("origem_lng", origemLng);
            resultIntent.putExtra("destino_lat", destinoLat);
            resultIntent.putExtra("destino_lng", destinoLng);
            resultIntent.putExtra("origem_endereco", origemEndereco);
            resultIntent.putExtra("destino_endereco", destinoEndereco);

            setResult(RESULT_OK, resultIntent);
            finish();
        });


        btnCancelar.setOnClickListener(view -> {
            setResult(RESULT_CANCELED);
            finish();
        });
    }
}
