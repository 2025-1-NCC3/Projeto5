package br.fecap.pi.uber;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class corrida extends AppCompatActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private LatLng origemLatLng, destinoLatLng;
    private Button btnSairdaCorrida, btnMandarPix, btnOpcoesCorrida;

    private double origemLat, origemLng, destinoLat, destinoLng;
    private String origemEndereco, destinoEndereco;

    private TextView textDistancia, textEnderecoCorrida, textViewChegada;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_corrida);

        btnSairdaCorrida = findViewById(R.id.btnSairdaCorrida);
        btnMandarPix = findViewById(R.id.btnMandarPix);
        btnOpcoesCorrida = findViewById(R.id.btnOpcoesCorrida);

        textEnderecoCorrida = findViewById(R.id.textEnderecoCorrida);
        textDistancia = findViewById(R.id.textView);
        textViewChegada = findViewById(R.id.textViewChegada);

        btnSairdaCorrida.setOnClickListener(view -> finish());

        btnMandarPix.setOnClickListener(view -> {
            Intent intentPix = new Intent(corrida.this, anexoPix.class);
            startActivity(intentPix);
        });

        btnOpcoesCorrida.setOnClickListener(view -> {
            Intent intentOpcoes = new Intent(corrida.this, telaOpcoes.class);
            intentOpcoes.putExtra("origem_lat", origemLat);
            intentOpcoes.putExtra("origem_lng", origemLng);
            intentOpcoes.putExtra("destino_lat", destinoLat);
            intentOpcoes.putExtra("destino_lng", destinoLng);
            intentOpcoes.putExtra("origem_endereco", origemEndereco);
            intentOpcoes.putExtra("destino_endereco", destinoEndereco);
            startActivityForResult(intentOpcoes, 1);
        });

        origemLat = getIntent().getDoubleExtra("origem_lat", 0);
        origemLng = getIntent().getDoubleExtra("origem_lng", 0);
        destinoLat = getIntent().getDoubleExtra("destino_lat", 0);
        destinoLng = getIntent().getDoubleExtra("destino_lng", 0);

        origemEndereco = getIntent().getStringExtra("origem_endereco");
        destinoEndereco = getIntent().getStringExtra("destino_endereco");

        origemLatLng = new LatLng(origemLat, origemLng);
        destinoLatLng = new LatLng(destinoLat, destinoLng);

        if (destinoEndereco != null && !destinoEndereco.isEmpty()) {
            textEnderecoCorrida.setText("Destino:\n" + destinoEndereco);
        } else {
            textEnderecoCorrida.setText(String.format("Destino: %.5f, %.5f",
                    destinoLatLng.latitude, destinoLatLng.longitude));
        }

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.mapCorrida);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        if (origemLatLng != null && destinoLatLng != null) {
            buscarRotaReal(origemLatLng, destinoLatLng);
        }
    }

    private void buscarRotaReal(LatLng origem, LatLng destino) {
        String url = "https://maps.googleapis.com/maps/api/directions/json?" +
                "origin=" + origem.latitude + "," + origem.longitude +
                "&destination=" + destino.latitude + "," + destino.longitude +
                "&key=AIzaSyCsQGHut9g8f-0xobKFkLsioNzkIKUbU0Q";

        RequestQueue queue = Volley.newRequestQueue(this);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                response -> {
                    try {
                        JSONObject jsonResponse = new JSONObject(response);
                        JSONArray routes = jsonResponse.getJSONArray("routes");
                        if (routes.length() == 0) {
                            Toast.makeText(this, "Nenhuma rota encontrada", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        JSONObject route = routes.getJSONObject(0);

                        JSONArray legs = route.getJSONArray("legs");
                        if (legs.length() > 0) {
                            JSONObject leg = legs.getJSONObject(0);

                            String distanciaTexto = leg.getJSONObject("distance").getString("text");
                            String duracaoTexto = leg.getJSONObject("duration").getString("text");

                            textDistancia.setText("Distância: " + distanciaTexto + " | Tempo: " + duracaoTexto);

                            int duracaoSegundos = leg.getJSONObject("duration").getInt("value");
                            atualizarHorarioChegada(duracaoSegundos);
                        }

                        JSONObject overviewPolyline = route.getJSONObject("overview_polyline");
                        String encodedPoints = overviewPolyline.getString("points");

                        List<LatLng> pontos = decodePolyline(encodedPoints);

                        mMap.clear();
                        mMap.addMarker(new MarkerOptions().position(origem).title("Origem"));
                        mMap.addMarker(new MarkerOptions().position(destino).title("Destino"));

                        PolylineOptions polylineOptions = new PolylineOptions()
                                .addAll(pontos)
                                .width(10)
                                .color(0xFF1E88E5)
                                .geodesic(true);
                        mMap.addPolyline(polylineOptions);

                        LatLng centro = new LatLng(
                                (origem.latitude + destino.latitude) / 2,
                                (origem.longitude + destino.longitude) / 2);
                        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(centro, 12));

                    } catch (JSONException e) {
                        e.printStackTrace();
                        Toast.makeText(this, "Erro ao processar rota", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> Toast.makeText(this, "Erro na requisição da rota", Toast.LENGTH_SHORT).show());

        queue.add(stringRequest);
    }

    private void atualizarHorarioChegada(int duracaoSegundos) {
        Calendar agora = Calendar.getInstance();
        agora.add(Calendar.SECOND, duracaoSegundos);

        SimpleDateFormat formatoHora = new SimpleDateFormat("HH:mm", Locale.getDefault());
        String horaChegada = formatoHora.format(agora.getTime());

        textViewChegada.setText("Chegada às " + horaChegada);
    }

    private List<LatLng> decodePolyline(String encoded) {
        List<LatLng> poly = new ArrayList<>();
        int index = 0, len = encoded.length();
        int lat = 0, lng = 0;

        while (index < len) {
            int b, shift = 0, result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lat += dlat;

            shift = 0;
            result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lng += dlng;

            LatLng p = new LatLng(((double) lat / 1E5), ((double) lng / 1E5));
            poly.add(p);
        }
        return poly;
    }


    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == 1 && resultCode == RESULT_OK && data != null) {
            origemLat = data.getDoubleExtra("origem_lat", origemLat);
            origemLng = data.getDoubleExtra("origem_lng", origemLng);
            destinoLat = data.getDoubleExtra("destino_lat", destinoLat);
            destinoLng = data.getDoubleExtra("destino_lng", destinoLng);
            origemEndereco = data.getStringExtra("origem_endereco");
            destinoEndereco = data.getStringExtra("destino_endereco");

            origemLatLng = new LatLng(origemLat, origemLng);
            destinoLatLng = new LatLng(destinoLat, destinoLng);

            if (destinoEndereco != null && !destinoEndereco.isEmpty()) {
                textEnderecoCorrida.setText("Destino:\n" + destinoEndereco);
            } else {
                textEnderecoCorrida.setText(String.format("Destino: %.5f, %.5f",
                        destinoLatLng.latitude, destinoLatLng.longitude));
            }

            if (mMap != null) {
                buscarRotaReal(origemLatLng, destinoLatLng);
            }
        }
    }
}
