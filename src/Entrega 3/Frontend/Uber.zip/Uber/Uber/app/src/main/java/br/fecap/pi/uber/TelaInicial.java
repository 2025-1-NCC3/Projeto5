package br.fecap.pi.uber;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.*;

import androidx.appcompat.app.AppCompatActivity;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TelaInicial extends AppCompatActivity {

    private EditText editTextEmail, editTextSenha;
    private Button buttonLogin, buttonRegister;
    private TextView textForgotPassword;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_inicial);

        editTextEmail = findViewById(R.id.editTextEmail);
        editTextSenha = findViewById(R.id.editTextSenha);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonRegister = findViewById(R.id.buttonRegister);
        textForgotPassword = findViewById(R.id.textForgotPassword);

        buttonLogin.setOnClickListener(v -> {
            String email = editTextEmail.getText().toString().trim();
            String senhaOriginal = editTextSenha.getText().toString().trim();

            if (email.isEmpty() || senhaOriginal.isEmpty()) {
                Toast.makeText(this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
                return;
            }

            String senhaCriptografada = SecurityUtils.hashPassword(senhaOriginal);
            loginUser(email, senhaCriptografada);
        });

        buttonRegister.setOnClickListener(v -> {
            startActivity(new Intent(this, MainActivity.class));
        });

        textForgotPassword.setOnClickListener(v -> {
            Toast.makeText(this, "Recuperação de senha ainda não implementada", Toast.LENGTH_SHORT).show();
        });
    }

    private void loginUser(String email, String senhaCriptografada) {
        ApiService apiService = ApiClient.getApiService();

        LoginRequest loginRequest = new LoginRequest(email, senhaCriptografada);

        apiService.loginUser(loginRequest).enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                if (response.isSuccessful() && response.body() != null && response.body().success) {
                    Toast.makeText(TelaInicial.this, "Login bem-sucedido", Toast.LENGTH_SHORT).show();


                    SharedPreferences prefs = getSharedPreferences("login", MODE_PRIVATE);
                    SharedPreferences.Editor editor = prefs.edit();
                    editor.putInt("userId", response.body().user.id);
                    editor.putString("email", response.body().user.email);
                    editor.apply();


                    startActivity(new Intent(TelaInicial.this, Menu.class));
                    finish();
                } else {
                    Toast.makeText(TelaInicial.this, "Credenciais inválidas", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                Log.e("LoginError", "Erro: " + t.getMessage());
                Toast.makeText(TelaInicial.this, "Erro na conexão com o servidor", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
