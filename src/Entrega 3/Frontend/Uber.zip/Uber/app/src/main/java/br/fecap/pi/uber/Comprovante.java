package br.fecap.pi.uber;

public class Comprovante {
    private String caminhoImagem;
    private String dataHora;

    public Comprovante(String caminhoImagem, String dataHora) {
        this.caminhoImagem = caminhoImagem;
        this.dataHora = dataHora;
    }

    public String getImagemPath() {
        return caminhoImagem;
    }

    public String getDataHora() {
        return dataHora;
    }
}
