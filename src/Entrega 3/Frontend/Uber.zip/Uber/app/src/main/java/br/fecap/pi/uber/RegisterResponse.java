package br.fecap.pi.uber;

public class RegisterResponse {
    public boolean success;
    public int id;
}
