package br.fecap.pi.uber;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class TelaInicial extends AppCompatActivity {

    private EditText editTextEmail, editTextSenha;
    private Button buttonLogin, buttonRegister;
    private TextView textForgotPassword;

    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_inicial);

        db = new DatabaseHelper(this);

        editTextEmail = findViewById(R.id.editTextEmail);  // Corrija a referência
        editTextSenha = findViewById(R.id.editTextSenha);  // Corrija a referência
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonRegister = findViewById(R.id.buttonRegister);
        textForgotPassword = findViewById(R.id.textForgotPassword);

        buttonLogin.setOnClickListener(v -> {
            String email = editTextEmail.getText().toString().trim();
            String rawSenha = editTextSenha.getText().toString().trim();

            if (email.isEmpty() || rawSenha.isEmpty()) {
                Toast.makeText(TelaInicial.this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
            } else {
                String senhaCriptografada = SecurityUtils.hashPassword(rawSenha);

                // Verifique o email e a senha corretamente
                boolean isValid = db.checkUser(email, senhaCriptografada);
                if (isValid) {
                    Toast.makeText(TelaInicial.this, "Login realizado com sucesso", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(TelaInicial.this, Menu.class);
                    startActivity(intent);
                    finish();
                } else {
                    Toast.makeText(TelaInicial.this, "Credenciais inválidas", Toast.LENGTH_SHORT).show();
                }
            }
        });

        buttonRegister.setOnClickListener(v -> {
            Intent intent = new Intent(TelaInicial.this, MainActivity.class);
            startActivity(intent);
        });

        textForgotPassword.setOnClickListener(v -> {
            Toast.makeText(TelaInicial.this, "Recuperação de senha ainda não implementada", Toast.LENGTH_SHORT).show();
        });
    }
}

