package br.fecap.pi.uber;

public class User {
    public String nome;
    public String sobrenome;
    public String telefone;
    public String email;
    public String senha;

    public int id;

    public User(String nome, String sobrenome, String telefone, String email, String senha) {
        this.nome = nome;
        this.sobrenome = sobrenome;
        this.telefone = telefone;
        this.email = email;
        this.senha = senha;
    }
}
