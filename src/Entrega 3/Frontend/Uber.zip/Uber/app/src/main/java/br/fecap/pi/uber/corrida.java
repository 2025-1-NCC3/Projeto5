package br.fecap.pi.uber;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class corrida extends AppCompatActivity {

    private Button btnOpcoesCorrida;
    private Button btnMandarPix;
    private Button btnSairdaCorrida;
    private Button btnPerfil;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnOpcoesCorrida = findViewById(R.id.btnOpcoesCorrida);
        btnMandarPix = findViewById(R.id.btnMandarPix);
        btnSairdaCorrida = findViewById(R.id.btnSairdaCorrida);
        btnPerfil = findViewById(R.id.btnPerfil);

        btnOpcoesCorrida.setOnClickListener(view -> {
            Intent intent = new Intent(corrida.this, telaOpcoes.class);
            startActivity(intent);
        });

        btnMandarPix.setOnClickListener(view ->{
            Intent intent = new Intent(corrida.this, anexoPix.class);
            startActivity(intent);
        });

        btnPerfil.setOnClickListener(view ->{
                Intent intent = new Intent(corrida.this, Perfil.class);
                startActivity(intent);
        });

    }
}
