package br.fecap.pi.uber;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;
import android.content.SharedPreferences;
import android.widget.TextView;


public class Perfil extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perfil);

        SharedPreferences sharedPreferences = getSharedPreferences("user_data", MODE_PRIVATE);

        String nome = sharedPreferences.getString("nome", "Nome não encontrado");
        String sobrenome = sharedPreferences.getString("sobrenome", "");
        String email = sharedPreferences.getString("email", "Email não encontrado");
        String telefone = sharedPreferences.getString("telefone", "Telefone não encontrado");


        TextView nomeText = findViewById(R.id.appNome);
        TextView emailText = findViewById(R.id.appEmail);
        TextView telefoneText = findViewById(R.id.appTelefone);

        nomeText.setText(nome + " " + sobrenome);
        emailText.setText(email);
        telefoneText.setText(telefone);


        Button btnVerComprovantes = findViewById(R.id.btnVerComprovantes);
        btnVerComprovantes.setOnClickListener(v -> {
            Intent intent = new Intent(Perfil.this, historicosPix.class);
            startActivity(intent);
        });


        getWindow().setStatusBarColor(getResources().getColor(R.color.preto));
        getWindow().setNavigationBarColor(getResources().getColor(R.color.preto));


        ImageView imgMenu = findViewById(R.id.imgMenu);
        imgMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Perfil.this, Menu.class);
                startActivity(intent);
                finish();
            }
        });
    }
}
