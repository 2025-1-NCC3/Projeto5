package br.fecap.pi.uber;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class telaCorrida extends AppCompatActivity {

    private Button btnOpcoesCorrida;
    private Button btnMandarPix;
    private Button btnSairdaCorrida;
    private Button btnPerfil;

    private TextView destinoTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_corrida);

        btnOpcoesCorrida = findViewById(R.id.btnOpcoesCorrida);
        btnMandarPix = findViewById(R.id.btnMandarPix);
        btnSairdaCorrida = findViewById(R.id.btnSairdaCorrida);
        btnPerfil = findViewById(R.id.btnPerfil);
        destinoTextView = findViewById(R.id.textEnderecoCorrida);

        btnPerfil.setOnClickListener(view ->{
            Intent intent = new Intent(telaCorrida.this, Perfil.class);
            startActivity(intent);
        });

        btnSairdaCorrida.setOnClickListener(view ->{
            Intent intent = new Intent(telaCorrida.this, Procurar.class);
            startActivity(intent);
        });

        btnPerfil.setOnClickListener(view ->{
            Intent intent = new Intent(telaCorrida.this, Perfil.class);
            startActivity(intent);
        });

        String destino = getIntent().getStringExtra("destino");

        if (destino != null && !destino.isEmpty()) {
            destinoTextView.setText("A caminho de: " + destino);
        }

        btnOpcoesCorrida.setOnClickListener(view -> {
            Intent intent = new Intent(telaCorrida.this, telaOpcoes.class);
            startActivity(intent);
        });

        btnMandarPix.setOnClickListener(view -> {
            Intent intent = new Intent(telaCorrida.this, anexoPix.class);
            startActivity(intent);
        });
    }
}
