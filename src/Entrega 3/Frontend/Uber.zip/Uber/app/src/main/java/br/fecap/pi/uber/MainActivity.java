package br.fecap.pi.uber;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.util.Patterns;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MainActivity extends AppCompatActivity {

    private EditText editTextFirstName, editTextLastName, editTextEmail, editTextPhone,
            editTextPassword, editTextCity, editTextReferralCode;
    private Button buttonRegister, buttonLogin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inicializarComponentes();

        buttonLogin.setOnClickListener(view -> {
            Intent intent = new Intent(MainActivity.this, TelaInicial.class);
            startActivity(intent);
        });

        buttonRegister.setOnClickListener(v -> registrarUsuario());
    }

    private void inicializarComponentes() {
        editTextFirstName = findViewById(R.id.editTextFirstName);
        editTextLastName = findViewById(R.id.editTextLastName);
        editTextEmail = findViewById(R.id.editTextEmail);
        editTextPhone = findViewById(R.id.editTextPhone);
        editTextPassword = findViewById(R.id.editTextPassword);
        editTextCity = findViewById(R.id.editTextCity);
        editTextReferralCode = findViewById(R.id.editTextReferralCode);
        buttonRegister = findViewById(R.id.buttonRegister);
        buttonLogin = findViewById(R.id.buttonLogin);
    }

    private void registrarUsuario() {
        String firstName = editTextFirstName.getText().toString().trim();
        String lastName = editTextLastName.getText().toString().trim();
        String email = editTextEmail.getText().toString().trim();
        String phone = editTextPhone.getText().toString().trim();
        String rawPassword = editTextPassword.getText().toString().trim();
        String city = editTextCity.getText().toString().trim();
        String referralCode = editTextReferralCode.getText().toString().trim();

        if (!validarCampos(firstName, lastName, email, phone, rawPassword, city)) return;

        ApiService apiService = ApiClient.getApiService();

        apiService.emailExists(email).enqueue(new Callback<EmailExistsResponse>() {
            @Override
            public void onResponse(Call<EmailExistsResponse> call, Response<EmailExistsResponse> response) {
                if (response.isSuccessful() && response.body() != null) {
                    if (response.body().exists) {
                        Toast.makeText(MainActivity.this, "E-mail já cadastrado!", Toast.LENGTH_SHORT).show();
                    } else {
                        String hashedPassword = SecurityUtils.hashPassword(rawPassword);
                        User user = new User(firstName, lastName, phone, email, hashedPassword);

                        apiService.registerUser(user).enqueue(new Callback<RegisterResponse>() {
                            @Override
                            public void onResponse(Call<RegisterResponse> call, Response<RegisterResponse> response) {
                                if (response.isSuccessful() && response.body().success) {
                                    Toast.makeText(MainActivity.this, "Cadastro realizado com sucesso!", Toast.LENGTH_SHORT).show();
                                    startActivity(new Intent(MainActivity.this, TelaInicial.class));
                                    finish();
                                } else {
                                    Toast.makeText(MainActivity.this, "Erro ao cadastrar", Toast.LENGTH_SHORT).show();
                                }
                            }

                            @Override
                            public void onFailure(Call<RegisterResponse> call, Throwable t) {
                                Toast.makeText(MainActivity.this, "Erro: " + t.getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                }
            }

            @Override
            public void onFailure(Call<EmailExistsResponse> call, Throwable t) {
                Toast.makeText(MainActivity.this, "Falha na verificação de e-mail: " + t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private boolean validarCampos(String nome, String sobrenome, String email, String telefone, String senha, String cidade) {
        if (nome.isEmpty() || sobrenome.isEmpty() || email.isEmpty() || telefone.isEmpty() || senha.isEmpty() || cidade.isEmpty()) {
            Toast.makeText(this, "Preencha todos os campos obrigatórios!", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            Toast.makeText(this, "E-mail inválido!", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (!telefone.matches("\\d{8,15}")) {
            Toast.makeText(this, "Telefone inválido! Use apenas números (mín. 8 dígitos).", Toast.LENGTH_SHORT).show();
            return false;
        }

        if (senha.length() < 6) {
            Toast.makeText(this, "A senha deve ter no mínimo 6 caracteres!", Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }
}
