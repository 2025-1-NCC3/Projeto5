package br.fecap.pi.uber;

public class EmailExistsResponse {
    public boolean exists;
}
