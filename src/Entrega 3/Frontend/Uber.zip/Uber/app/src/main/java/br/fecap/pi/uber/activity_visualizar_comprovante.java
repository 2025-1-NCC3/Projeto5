package br.fecap.pi.uber;

import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;

import androidx.appcompat.app.AppCompatActivity;

public class activity_visualizar_comprovante extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_visualizar_comprovante);

        ImageView imageView = findViewById(R.id.imagem_completa);
        Button btnVoltar = findViewById(R.id.btnVoltarHistorico);

        String caminho = getIntent().getStringExtra("caminho");
        if (caminho != null) {
            imageView.setImageBitmap(BitmapFactory.decodeFile(caminho));
        }

        btnVoltar.setOnClickListener(v -> finish());
    }
}
