package br.fecap.pi.uber;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.*;

import java.util.*;

public class historicosPix extends AppCompatActivity {

    private RecyclerView recyclerView;
    private ComprovanteAdapter adapter;
    private List<Comprovante> listaComprovantes = new ArrayList<>();

    private DatabaseHelper db;
    private int userId;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_historicos_pix);

        SharedPreferences prefs = getSharedPreferences("login", MODE_PRIVATE);
        userId = prefs.getInt("userId", -1);

        recyclerView = findViewById(R.id.recyclerComprovantes);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));

        db = new DatabaseHelper(this);
        carregarComprovantes();

        Button btnVoltarPerfil = findViewById(R.id.btnVoltarPerfil);
        btnVoltarPerfil.setOnClickListener(v -> {
            startActivity(new Intent(this, Perfil.class));
            finish();
        });
    }

    private void carregarComprovantes() {
        listaComprovantes.clear();
        Cursor cursor = db.listarComprovantesPorUsuario(userId);
        if (cursor.moveToFirst()) {
            do {
                String caminho = cursor.getString(cursor.getColumnIndexOrThrow("imagem_path"));
                String data = cursor.getString(cursor.getColumnIndexOrThrow("data"));
                listaComprovantes.add(new Comprovante(caminho, data));
            } while (cursor.moveToNext());
        }
        cursor.close();

        adapter = new ComprovanteAdapter(this, listaComprovantes);
        recyclerView.setAdapter(adapter);
    }
}
