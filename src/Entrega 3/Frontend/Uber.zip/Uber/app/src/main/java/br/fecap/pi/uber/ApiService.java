package br.fecap.pi.uber;

import retrofit2.Call;
import retrofit2.http.*;

public interface ApiService {

    @GET("email-exists/{email}")
    Call<EmailExistsResponse> emailExists(@Path("email") String email);

    @POST("register")
    Call<RegisterResponse> registerUser(@Body User user);

    @POST("/login")
    Call<LoginResponse> loginUser(@Body LoginRequest loginRequest);

}
