package br.fecap.pi.uber;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class telaOpcoes extends AppCompatActivity {

    private Button btnVoltarViagem;
    private Button btnMudarForma;
    private Button btnCancelar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tela_opcoes);

        btnVoltarViagem = findViewById(R.id.btnVoltarViagem);
        btnMudarForma = findViewById(R.id.btnMudarForma);
        btnCancelar = findViewById(R.id.btnCancelar);

        btnMudarForma.setOnClickListener(view -> {
            Intent intent = new Intent(telaOpcoes.this, mudarPagamento.class);
            startActivity(intent);
        });

        btnVoltarViagem.setOnClickListener(view -> {
            Intent intent = new Intent(telaOpcoes.this, telaCorrida.class);
            startActivity(intent);
        });

        btnCancelar.setOnClickListener(view -> {
            Intent intent = new Intent(telaOpcoes.this, Procurar.class);
            startActivity(intent);
        });
    }
}