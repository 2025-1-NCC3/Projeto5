package br.fecap.pi.uber;

public class LoginResponse {
    public boolean success;
    public String message;
    public User user;
}