package br.fecap.pi.uber;

import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.io.File;
import java.util.List;

public class ComprovanteAdapter extends RecyclerView.Adapter<ComprovanteAdapter.ViewHolder> {

    private Context context;
    private List<Comprovante> listaComprovantes;


    public ComprovanteAdapter(Context context, List<Comprovante> listaComprovantes) {
        this.context = context;
        this.listaComprovantes = listaComprovantes;
    }


    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_comprovante, parent, false);
        return new ViewHolder(view);
    }


    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Comprovante comprovante = listaComprovantes.get(position);
        File imgFile = new File(comprovante.getImagemPath());

        if (imgFile.exists()) {
            holder.imageView.setImageBitmap(BitmapFactory.decodeFile(comprovante.getImagemPath()));
            holder.textData.setText(comprovante.getDataHora());


            holder.imageView.setOnClickListener(v -> {
                Intent intent = new Intent(context, activity_visualizar_comprovante.class);
                intent.putExtra("caminho", comprovante.getImagemPath());
                context.startActivity(intent);
            });
        }
    }


    @Override
    public int getItemCount() {
        return listaComprovantes.size();

    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView imageView;
        TextView textData;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.imagemComprovante);
            textData = itemView.findViewById(R.id.textDataComprovante);
        }

    }




}
