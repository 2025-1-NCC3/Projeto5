package br.fecap.pi.uber;

import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;
import java.util.Date;

public class anexoPix extends AppCompatActivity {

    private static final int REQUEST_IMAGE_CAPTURE = 1;
    private static final int REQUEST_GALLERY_IMAGE = 2;

    private ImageView imageView;
    private Button btnVoltardoPix, buttonTakePhoto, buttonChoosePhoto;

    private File imageFile;
    private int userId;
    String imagemPath;

    private double origemLat, origemLng, destinoLat, destinoLng;
    private String origemEndereco, destinoEndereco;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_anexo_pix);

        SharedPreferences prefs = getSharedPreferences("login", MODE_PRIVATE);
        userId = prefs.getInt("userId", -1);

        imageView = findViewById(R.id.comprovante_image);
        btnVoltardoPix = findViewById(R.id.btnVoltardoPix);
        buttonTakePhoto = findViewById(R.id.button_take_photo);
        buttonChoosePhoto = findViewById(R.id.button_choose_photo);

        Intent intent = getIntent();
        origemLat = intent.getDoubleExtra("origem_lat", 0);
        origemLng = intent.getDoubleExtra("origem_lng", 0);
        destinoLat = intent.getDoubleExtra("destino_lat", 0);
        destinoLng = intent.getDoubleExtra("destino_lng", 0);
        origemEndereco = intent.getStringExtra("origem_endereco");
        destinoEndereco = intent.getStringExtra("destino_endereco");

        btnVoltardoPix.setOnClickListener(view -> voltarParaCorrida());

        buttonTakePhoto.setOnClickListener(v -> dispatchTakePictureIntent());

        buttonChoosePhoto.setOnClickListener(v -> dispatchChoosePictureIntent());
    }

    private void voltarParaCorrida() {
        Intent intentResultado = new Intent();
        intentResultado.putExtra("origem_lat", origemLat);
        intentResultado.putExtra("origem_lng", origemLng);
        intentResultado.putExtra("destino_lat", destinoLat);
        intentResultado.putExtra("destino_lng", destinoLng);
        intentResultado.putExtra("origem_endereco", origemEndereco);
        intentResultado.putExtra("destino_endereco", destinoEndereco);
        setResult(RESULT_OK, intentResultado);
        finish();
    }

    @Override
    public void onBackPressed() {
        voltarParaCorrida();
    }

    private void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            imageFile = createImageFile();
            if (imageFile != null) {
                Uri photoURI = FileProvider.getUriForFile(this, getPackageName() + ".provider", imageFile);
                takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
                startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
            } else {
                Toast.makeText(this, "Erro ao criar arquivo de imagem", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void dispatchChoosePictureIntent() {
        Intent choosePictureIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        choosePictureIntent.setType("image/*");
        startActivityForResult(choosePictureIntent, REQUEST_GALLERY_IMAGE);
    }

    private File createImageFile() {
        try {
            String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
            File storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES);
            return new File(storageDir, "PIX_" + timeStamp + ".jpg");
        } catch (Exception e) {
            Log.e("anexoPix", "Erro criando arquivo de imagem", e);
            return null;
        }
    }

    private void saveBitmapToFile(Bitmap bitmap, int userId) {
        try {
            imageFile = createImageFile();
            if (imageFile == null) {
                Toast.makeText(this, "Erro ao criar arquivo para salvar imagem", Toast.LENGTH_SHORT).show();
                return;
            }
            FileOutputStream out = new FileOutputStream(imageFile);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 90, out);
            out.close();

            String dataAtual = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date());
            DatabaseHelper db = new DatabaseHelper(this);
            db.salvarComprovante(imageFile.getAbsolutePath(), dataAtual, userId);

            Toast.makeText(this, "Imagem salva", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Erro ao salvar imagem", Toast.LENGTH_SHORT).show();
            Log.e("anexoPix", "Erro salvando bitmap", e);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        Log.d("BANCO", "Salvando comprovante: " + imagemPath + ", userId: " + userId);

        if (resultCode == RESULT_OK) {
            if (requestCode == REQUEST_IMAGE_CAPTURE) {
                if (imageFile != null && imageFile.exists()) {
                    imageView.setImageURI(Uri.fromFile(imageFile));

                    String dataAtual = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss").format(new Date());
                    DatabaseHelper db = new DatabaseHelper(this);
                    db.salvarComprovante(imageFile.getAbsolutePath(), dataAtual, userId);

                    Toast.makeText(this, "Comprovante salvo", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, "Erro ao capturar imagem", Toast.LENGTH_SHORT).show();
                }
            } else if (requestCode == REQUEST_GALLERY_IMAGE && data != null && data.getData() != null) {
                Uri selectedImageUri = data.getData();
                imageView.setImageURI(selectedImageUri);

                try {
                    Bitmap bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), selectedImageUri);
                    saveBitmapToFile(bitmap, userId);
                } catch (Exception e) {
                    Toast.makeText(this, "Erro ao processar imagem", Toast.LENGTH_SHORT).show();
                    Log.e("anexoPix", "Erro processando imagem da galeria", e);
                }
            }
        }
    }
}
