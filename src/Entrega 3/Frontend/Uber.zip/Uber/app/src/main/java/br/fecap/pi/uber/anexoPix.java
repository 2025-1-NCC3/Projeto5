package br.fecap.pi.uber;

import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class anexoPix extends AppCompatActivity {

    private static final int REQUEST_IMAGE_CAPTURE = 1;
    private static final int REQUEST_GALLERY_IMAGE = 2;

    private ImageView imageView;
    private Button btnVoltardoPix, buttonTakePhoto, buttonChoosePhoto;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_anexo_pix);

        imageView = findViewById(R.id.comprovante_image);
        btnVoltardoPix = findViewById(R.id.btnVoltardoPix);
        buttonTakePhoto = findViewById(R.id.button_take_photo);
        buttonChoosePhoto = findViewById(R.id.button_choose_photo);

        btnVoltardoPix.setOnClickListener(view -> {
            Intent intent = new Intent(anexoPix.this, telaCorrida.class);
            startActivity(intent);
        });

        buttonTakePhoto.setOnClickListener(v -> dispatchTakePictureIntent());

        buttonChoosePhoto.setOnClickListener(v -> dispatchChoosePictureIntent());
    }

    private void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(getPackageManager()) != null) {
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
        } else {
            Toast.makeText(this, "A câmera não está disponível", Toast.LENGTH_SHORT).show();
        }
    }

    private void dispatchChoosePictureIntent() {
        Intent choosePictureIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        choosePictureIntent.setType("image/*");
        startActivityForResult(choosePictureIntent, REQUEST_GALLERY_IMAGE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK) {
            if (requestCode == REQUEST_IMAGE_CAPTURE) {
                Bundle extras = data.getExtras();
                Bitmap imageBitmap = (Bitmap) extras.get("data");
                imageView.setImageBitmap(imageBitmap);
            } else if (requestCode == REQUEST_GALLERY_IMAGE) {
                try {
                    Bitmap imageBitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), data.getData());
                    imageView.setImageBitmap(imageBitmap);
                } catch (Exception e) {
                    Toast.makeText(this, "Erro ao escolher imagem", Toast.LENGTH_SHORT).show();
                }
            }
        }
    }
}

