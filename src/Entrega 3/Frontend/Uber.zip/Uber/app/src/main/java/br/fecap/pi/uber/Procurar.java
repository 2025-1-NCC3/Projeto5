package br.fecap.pi.uber;

import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;

import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;

import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.widget.AutocompleteSupportFragment;
import com.google.android.libraries.places.widget.listener.PlaceSelectionListener;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Procurar extends AppCompatActivity implements OnMapReadyCallback {

    private static final String TAG = "Procurar";

    private GoogleMap mMap;
    private LatLng origemLatLng;
    private LatLng destinoLatLng;

    private String origemEndereco;
    private String destinoEndereco;

    private FusedLocationProviderClient fusedLocationClient;
    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "onCreate iniciado");
        setContentView(R.layout.activity_procurar);

        Button btnSair = findViewById(R.id.btnSairdoProcurar);
        btnSair.setOnClickListener(v -> {
            Log.d(TAG, "Botão Sair clicado");
            finish();
        });

        if (!Places.isInitialized()) {
            Places.initialize(getApplicationContext(), "AIzaSyCsQGHut9g8f-0xobKFkLsioNzkIKUbU0Q");
            Log.d(TAG, "Places inicializado");
        }

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
            Log.d(TAG, "Solicitado getMapAsync");
        } else {
            Log.e(TAG, "mapFragment é null");
        }

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.ACCESS_FINE_LOCATION},
                    LOCATION_PERMISSION_REQUEST_CODE);
        } else {
            obterLocalizacaoAtual();
        }

        setupAutoComplete();
        setupBotaoEnviar();

        Log.d(TAG, "onCreate finalizado");
    }

    private void obterLocalizacaoAtual() {
        fusedLocationClient.getLastLocation()
                .addOnSuccessListener(this, location -> {
                    if (location != null) {
                        origemLatLng = new LatLng(location.getLatitude(), location.getLongitude());
                        origemEndereco = "Minha localização";
                        Log.d(TAG, "Localização atual obtida: " + origemLatLng.toString());

                        if (mMap != null) {
                            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(origemLatLng, 15));
                            mMap.addMarker(new MarkerOptions().position(origemLatLng).title("Minha Localização"));
                        }
                    } else {
                        Log.w(TAG, "Localização atual é nula");
                    }
                });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                obterLocalizacaoAtual();
            } else {
                Toast.makeText(this, "Permissão de localização negada", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void setupAutoComplete() {
        Log.d(TAG, "setupAutoComplete iniciado");
        AutocompleteSupportFragment autocompleteOrigem = (AutocompleteSupportFragment)
                getSupportFragmentManager().findFragmentById(R.id.autocomplete_fragment_origem);
        AutocompleteSupportFragment autocompleteDestino = (AutocompleteSupportFragment)
                getSupportFragmentManager().findFragmentById(R.id.autocomplete_fragment_destino);

        List<Place.Field> placeFields = Arrays.asList(Place.Field.ID, Place.Field.NAME, Place.Field.LAT_LNG);
        autocompleteOrigem.setPlaceFields(placeFields);
        autocompleteDestino.setPlaceFields(placeFields);

        autocompleteOrigem.setHint("Escolha a origem");
        autocompleteDestino.setHint("Escolha o destino");

        autocompleteOrigem.setOnPlaceSelectedListener(new PlaceSelectionListener() {
            @Override
            public void onPlaceSelected(@NonNull Place place) {
                origemLatLng = place.getLatLng();
                origemEndereco = place.getName();
                Log.d(TAG, "Origem selecionada: " + origemEndereco);
                desenharRotaSePossivel();
            }

            @Override
            public void onError(@NonNull com.google.android.gms.common.api.Status status) {
                Log.e(TAG, "Erro ao selecionar origem: " + status.getStatusMessage());
                Toast.makeText(Procurar.this, "Erro ao selecionar origem: " + status.getStatusMessage(), Toast.LENGTH_SHORT).show();
            }
        });

        autocompleteDestino.setOnPlaceSelectedListener(new PlaceSelectionListener() {
            @Override
            public void onPlaceSelected(@NonNull Place place) {
                destinoLatLng = place.getLatLng();
                destinoEndereco = place.getName();
                Log.d(TAG, "Destino selecionado: " + destinoEndereco);
                desenharRotaSePossivel();
            }

            @Override
            public void onError(@NonNull com.google.android.gms.common.api.Status status) {
                Log.e(TAG, "Erro ao selecionar destino: " + status.getStatusMessage());
                Toast.makeText(Procurar.this, "Erro ao selecionar destino: " + status.getStatusMessage(), Toast.LENGTH_SHORT).show();
            }
        });
        Log.d(TAG, "setupAutoComplete finalizado");
    }

    private void setupBotaoEnviar() {
        Log.d(TAG, "setupBotaoEnviar iniciado");
        Button btnEnviar = findViewById(R.id.btnEnviarDestino);
        btnEnviar.setOnClickListener(v -> {
            Log.d(TAG, "Botão Enviar clicado");
            if (origemLatLng != null && destinoLatLng != null) {
                Intent intent = new Intent(Procurar.this, corrida.class);
                intent.putExtra("origem_lat", origemLatLng.latitude);
                intent.putExtra("origem_lng", origemLatLng.longitude);
                intent.putExtra("destino_lat", destinoLatLng.latitude);
                intent.putExtra("destino_lng", destinoLatLng.longitude);

                intent.putExtra("origem_endereco", origemEndereco);
                intent.putExtra("destino_endereco", destinoEndereco);

                Log.d(TAG, "Iniciando activity Corrida");
                startActivity(intent);
                finish();
            } else {
                Log.w(TAG, "Origem ou destino não selecionados");
                Toast.makeText(this, "Escolha origem e destino antes de enviar", Toast.LENGTH_SHORT).show();
            }
        });
        Log.d(TAG, "setupBotaoEnviar finalizado");
    }

    @Override
    public void onMapReady(@NonNull GoogleMap googleMap) {
        Log.d(TAG, "onMapReady chamado");
        mMap = googleMap;

        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED) {
            mMap.setMyLocationEnabled(true);
        }

        if (origemLatLng != null) {
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(origemLatLng, 15));
            mMap.addMarker(new MarkerOptions().position(origemLatLng).title("Minha Localização"));
        } else {
            LatLng sp = new LatLng(-23.55052, -46.633308);
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(sp, 10));
            Log.d(TAG, "Mapa centralizado em São Paulo");
        }
    }

    private void desenharRotaSePossivel() {
        if (mMap == null) {
            Log.w(TAG, "Mapa não inicializado ainda");
            return;
        }

        Log.d(TAG, "desenharRotaSePossivel chamado");
        mMap.clear();

        if (origemLatLng != null && destinoLatLng != null) {
            buscarRotaReal(origemLatLng, destinoLatLng);
        } else {
            if (origemLatLng != null) {
                mMap.addMarker(new MarkerOptions().position(origemLatLng).title("Origem"));
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(origemLatLng, 15));
                Log.d(TAG, "Mapa movido para origem");
            }
            if (destinoLatLng != null) {
                mMap.addMarker(new MarkerOptions().position(destinoLatLng).title("Destino"));
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(destinoLatLng, 15));
                Log.d(TAG, "Mapa movido para destino");
            }
        }
    }

    private void buscarRotaReal(LatLng origem, LatLng destino) {
        if (origem == null || destino == null) return;

        String url = "https://maps.googleapis.com/maps/api/directions/json?" +
                "origin=" + origem.latitude + "," + origem.longitude +
                "&destination=" + destino.latitude + "," + destino.longitude +
                "&key=AIzaSyCsQGHut9g8f-0xobKFkLsioNzkIKUbU0Q";

        RequestQueue queue = Volley.newRequestQueue(this);

        StringRequest stringRequest = new StringRequest(Request.Method.GET, url,
                response -> {
                    try {
                        JSONObject jsonResponse = new JSONObject(response);
                        JSONArray routes = jsonResponse.getJSONArray("routes");
                        if (routes.length() == 0) {
                            Toast.makeText(this, "Nenhuma rota encontrada", Toast.LENGTH_SHORT).show();
                            return;
                        }
                        JSONObject route = routes.getJSONObject(0);
                        JSONObject overviewPolyline = route.getJSONObject("overview_polyline");
                        String encodedPoints = overviewPolyline.getString("points");

                        List<LatLng> pontos = decodePolyline(encodedPoints);

                        mMap.clear();
                        mMap.addMarker(new MarkerOptions().position(origem).title("Origem"));
                        mMap.addMarker(new MarkerOptions().position(destino).title("Destino"));

                        PolylineOptions polylineOptions = new PolylineOptions()
                                .addAll(pontos)
                                .width(10)
                                .color(0xFF2196F3)
                                .geodesic(true);
                        mMap.addPolyline(polylineOptions);

                        mMap.moveCamera(CameraUpdateFactory.newLatLngBounds(
                                getBoundsForLatLngList(pontos), 100));

                    } catch (JSONException e) {
                        e.printStackTrace();
                        Log.e(TAG, "Erro JSON: " + e.getMessage());
                        Toast.makeText(this, "Erro ao buscar rota", Toast.LENGTH_SHORT).show();
                    }
                },
                error -> {
                    Log.e(TAG, "Erro no Volley: " + error.toString());
                    Toast.makeText(this, "Erro ao conectar ao serviço de rotas", Toast.LENGTH_SHORT).show();
                });

        queue.add(stringRequest);
    }

    private List<LatLng> decodePolyline(String encoded) {
        List<LatLng> poly = new ArrayList<>();
        int index = 0, len = encoded.length();
        int lat = 0, lng = 0;

        while (index < len) {
            int b, shift = 0, result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lat += dlat;

            shift = 0;
            result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lng += dlng;

            LatLng p = new LatLng(
                    (double) lat / 1E5,
                    (double) lng / 1E5);
            poly.add(p);
        }
        return poly;
    }

    private com.google.android.gms.maps.model.LatLngBounds getBoundsForLatLngList(List<LatLng> latLngList) {
        com.google.android.gms.maps.model.LatLngBounds.Builder builder = new com.google.android.gms.maps.model.LatLngBounds.Builder();
        for (LatLng latLng : latLngList) {
            builder.include(latLng);
        }
        return builder.build();
    }
}
